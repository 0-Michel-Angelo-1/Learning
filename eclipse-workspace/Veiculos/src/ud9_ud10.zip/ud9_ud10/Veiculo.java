package ud9_ud10;

public abstract class Veiculo {
	
	public boolean ligado = false;
	
	public abstract void ligar();
	
	public abstract void desligar();
	
	public abstract boolean isLigado();

}
